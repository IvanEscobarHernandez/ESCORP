<!-- ../Librerias de formato -->
<meta charset="UTF-8">
<!-- <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> -->

<link rel="stylesheet" type="text/css" href="../librerias/alertify/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../librerias/alertify/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">
<link rel="stylesheet" href="../librerias/fontawesome/css/all.css">
<link rel="stylesheet" href="../librerias/fontawesome/css/brands.css">
<link rel="stylesheet" href="../librerias/fontawesome/css/solid.css">
<link rel="stylesheet" href="../librerias/datatables/datatables.css">


<!-- <script src="../librerias/jquery-3.5.1.min.js"> </script> -->
<script src="../librerias/jQuery-3.7.0/jquery-3.7.0.js"> </script>
<script src="../librerias/datatables/datatables.js"> </script>
<script src="../librerias/alertify/alertify.js"> </script>
<script src="../librerias/bootstrap/js/bootstrap.js"> </script>
<script src="../librerias/bootstrap/js/bootstrap.min.js"> </script>
<script src="../librerias/select2/js/select2.js"> </script>
<script src="../librerias/select2/js/select2.js"> </script>
<!-- <script src="../librerias/datatable/jquery.dataTables.min.js"></script>
<script src="../librerias/datatable/dataTables.bootstrap.min.js"></script> -->
<script src="https://kit.fontawesome.com/56958c1105.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Tablas -->
<!-- BUscador y traduccion tablas -->
<!-- <link rel = "stylesheet" type = "text/css" href = "../librerias/datatable/bootstrap.min.css">
<link rel = "stylesheet" type = "text/css" href = "../librerias/datatable/dataTables.bootstrap.min.css"> -->
