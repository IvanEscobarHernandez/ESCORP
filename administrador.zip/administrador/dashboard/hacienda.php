<?php
session_start();

require_once "../funciones/conexion.php";
$user = $_SESSION['idUser'];

//Cierra sesion despues de cierto tiempo
$obj = new cerrarSesion($user);
/* echo $obj->cerrarSesiones($user); */

if (isset($_SESSION['user'])) {
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Catálogo hacienda</title>
        <link href="css/hacienda.css" rel="stylesheet">

        <!-- Font awesome -->
        <script src="https://kit.fontawesome.com/56958c1105.js" crossorigin="anonymous"></script>

        <!-- sweetalert -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <!-- Bootstrap -->

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <?php
        require_once "menu.php";
        ?>
    </head>

    <body>

        <div id="tablasHaciendaLoad"></div>

        <!-- Modal Agregar Nuevo-->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Agregar nuevo Tipo persona </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-6 needs-validation">
                            <div class="container-fluid">

                                <div class="row justify-content-around">
                                    <div class="col-md-12 position-relative">
                                        <label for="tipoPersona" class="form-label">Tipo persona</label>
                                        <input type="text" class="form-control" name="tipoPersona" id="tipoPersona" style="text-transform:uppercase;">
                                    </div>
                                </div>


                                <div class="row">

                                    <div class="col-4" style="display: flex;justify-content: center; margin-top:10px !important;">
                                        <button type="button" class="btn btn-third" data-bs-dismiss="modal">Cerrar</button>
                                    </div>

                                    <div class="col-4"></div>

                                    <div class="col-4" style="display: flex;justify-content: center; margin-top:10px !important;">
                                        <button class="btn btn-primary" type="submit" id="guardar"><i class="fa-solid fa-floppy-disk"></i> Guardar</button>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Editar-->
        <div class="modal fade" id="modalEdicion" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Actualiza Tipo persona </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-6 needs-validation">
                            <div class="container-fluid">

                                <div class="row justify-content-around">
                                    <div class="col-md-12 position-relative">

                                        <input type="text" class="form-control" name="id_personaU" id="id_personaU" Hidden="">

                                        <label for="tipoPersonaU" class="form-label">Tipo persona</label>
                                        <input type="text" class="form-control" name="tipoPersonaU" id="tipoPersonaU" style="text-transform:uppercase;">
                                    </div>
                                </div>


                                <div class="row">

                                    <div class="col-4" style="display: flex;justify-content: center;">
                                        <button type="button" class="btn btn-third btn-xs" data-bs-dismiss="modal">Cerrar</button>
                                    </div>

                                    <div class="col-4"></div>

                                    <div class="col-4" style="display: flex;justify-content: center;">
                                        <button class="btn btn-primary" type="submit" id="editar"><i class="fa-solid fa-floppy-disk"></i> Editar</button>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>

    </html>

    

    <script type="text/javascript">
        $(document).ready(function() {

            $('#tablasHaciendaLoad').load("vistas/empresas/tablasHacienda.php");

            $('#guardar').click(function() {

                /* Validacion de campo */
                let tipoPersona = document.getElementById("tipoPersona").value;
                var expresion = /^[a-zA-ZÀ-ÿ\s]{1,40}$/;
                /* console.log(tipoPersona); */
                if (tipoPersona == "") {
                    Swal.fire({
                        icon: 'warning',
                        iconColor: 'blue',
                        title: 'Campo vacío',
                        text: 'El campo "Tipo persona" es obligatorio!',
                        confirmButtonColor: 'blue',
                        showConfirmButton: true,
                    });
                    return false;
                } else if (!expresion.test(tipoPersona)) {
                    Swal.fire({
                        icon: 'warning',
                        iconColor: 'blue',
                        title: 'Campo inválido',
                        html: 'El campo "Tipo persona" no es valido! <br><br> El campo solo admite texto',
                        confirmButtonColor: 'blue',
                        showConfirmButton: true,
                    });
                    return false;
                }

                $.ajax({
                    type: "POST",
                    data: {
                        tipoPersona: $('#tipoPersona').val()
                    },
                    url: "../procesos/empresa/agregaTipoPersona.php",
                    success: function(r) {
                        /* alert(r); */
                        switch (r) {
                            case '0':
                                Swal.fire({
                                    icon: 'error',
                                    iconColor: 'red',
                                    title: '¡ERROR!',
                                    text: 'El tipo de persona no se ha registrado. Refresque la página e intente de nuevo.'
                                })
                                break;

                            case '1':
                                Swal.fire({
                                    icon: 'success',
                                    title: 'El tipo de persona se registro de manera exitosa.',
                                    showConfirmButton: false,
                                    timer: 2000
                                });
                                setTimeout('window.location.reload() ;', 2000);
                                break;

                            case '2':
                                Swal.fire({
                                    icon: 'warning',
                                    iconColor: 'blue',
                                    title: 'Datos repetidos',
                                    text: 'Tipo de persona ya se encuentran dado de alta!',
                                    confirmButtonColor: 'blue',
                                    showConfirmButton: true,
                                })
                                break;

                            case '3':
                                Swal.fire({
                                    icon: 'warning',
                                    iconColor: 'blue',
                                    title: 'Número máximo de registros alcanzado',
                                    text: 'Elimine alguno de los registros para poder continuar!',
                                    confirmButtonColor: 'blue',
                                    showConfirmButton: true,
                                })
                                break;
                        }

                    }
                });
            });


            $('#editar').click(function() {

                /* Validacion de campo */
                let tipoPersonaU = document.getElementById("tipoPersonaU").value;
                var expresion = /^[a-zA-ZÀ-ÿ\s]{1,40}$/;
                /* console.log(tipoPersonaU); */
                if (tipoPersonaU == "") {
                    Swal.fire({
                        icon: 'warning',
                        iconColor: 'blue',
                        title: 'Campo vacío',
                        text: 'El campo "Tipo persona" es obligatorio!',
                        confirmButtonColor: 'blue',
                        showConfirmButton: true,
                    });
                    return false;
                } else if (!expresion.test(tipoPersonaU)) {
                    Swal.fire({
                        icon: 'warning',
                        iconColor: 'blue',
                        title: 'Campo inválido',
                        html: 'El campo "Tipo persona" no es valido! <br><br> El campo solo admite texto',
                        confirmButtonColor: 'blue',
                        showConfirmButton: true,
                    });
                    return false;
                }

                $.ajax({
                    type: "POST",
                    data: {
                        id_personaU: $('#id_personaU').val(),
                        tipoPersonaU: $('#tipoPersonaU').val()
                    },
                    url: "../procesos/empresa/actualizaTipoPersona.php",
                    success: function(r) {
                        /* alert(r); */
                        switch (r) {
                            case '0':
                                Swal.fire({
                                    icon: 'error',
                                    iconColor: 'red',
                                    title: '¡ERROR!',
                                    text: 'El tipo de persona no se ha editado. Refresque la página e intente de nuevo.'
                                })
                                break;

                            case '1':
                                Swal.fire({
                                    icon: 'success',
                                    title: 'El tipo de persona se editó de manera exitosa.',
                                    showConfirmButton: false,
                                    timer: 2000
                                });
                                setTimeout('window.location.reload() ;', 2000);
                                break;

                            case '2':
                                Swal.fire({
                                    icon: 'warning',
                                    iconColor: 'blue',
                                    title: 'Datos repetidos',
                                    text: 'Tipo de persona ya se encuentran dado de alta!',
                                    confirmButtonColor: 'blue',
                                    showConfirmButton: true,
                                })
                                break;
                        }

                    }
                });


            });
        });

        function agregaDatosPersona(id_persona, tipoPersona) {
            $('#id_personaU').val(id_persona);
            $('#tipoPersonaU').val(tipoPersona);
        }

        function eliminaDatosPersona(id_persona) {

            Swal.fire({
                title: '¿Esta seguro?',
                text: "¿Desea eliminar el registro seleccionado?",
                icon: 'warning',
                iconColor: 'red',
                showCancelButton: true,
                cancelButtonColor: 'btn-third',
                confirmButtonColor: '#d33',
                confirmButtonText: 'Eliminar'
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        type: "POST",
                        data: "id_persona=" + id_persona,
                        url: "../procesos/empresa/eliminaTipoPersona.php",
                        success: function(r) {
                            /* alert(r); */
                            if (r == 1) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'El tipo de persona se eliminó de manera exitosa.',
                                    showConfirmButton: false,
                                    timer: 2000
                                });
                                setTimeout('window.location.reload() ;', 2000);
                            } else {
                                alertify.error('ERROR');
                                alertify.alert('Error', 'El laboratorio no se ha podido eliminar. Refresque la pagina e intente de nuevo');
                            }
                        }
                    });



                }
            })

        }
    </script>

<?php
} else {
    header("location:../index.php");
}

?>