<?php
session_start();

require_once "../../../funciones/conexion.php";
$user = $_SESSION['idUser'];

//Cierra sesion despues de cierto tiempo
$obj = new cerrarSesion($user);
/* echo $obj->cerrarSesiones($user); */

if (isset($_SESSION['user'])) {
	$c = new conectar();
	$conexion = $c->conexion();
	$sql = "SELECT id_persona,tipoPersona 
            FROM cpersona";
	$result = mysqli_query($conexion, $sql);
	$result2 = mysqli_query($conexion, $sql);

?>
	<!DOCTYPE html>
	<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Inicio</title>
		<link href="../../css/hacienda.css" rel="stylesheet">

		<!-- Font awesome -->
		<script src="https://kit.fontawesome.com/56958c1105.js" crossorigin="anonymous"></script>

		<!--Export table button CSS-->
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">

	</head>

	<body>
		<div class="container-body">
			<!--**********************************
            Content body start
        ***********************************-->
			<div class="content-body">

				<div class="row">

					<div class="col-6" style="padding:0px !important;">
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="tipoPersonaTabla1" class="table table-hover table-condensed">
										<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" id="botonNuevo"><i class="fa-solid fa-square-plus"></i> Agregar nuevo</button>
										<thead>
											<tr>
												<th style="width:80%; text-align: center;">Tipo persona</th>
												<th></th>
												<th></th>
											</tr>
										</thead>
										<tbody>
											<?php while ($ver = mysqli_fetch_row($result)) : ?>
												<tr>
													<td style="width: 90%;"> <?php echo $ver[1]; ?> </td>
													<td class="btns"> <button type="button" class="btn btn-primary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#modalEdicion" onclick="agregaDatosPersona('<?php echo $ver[0] ?>','<?php echo $ver[1] ?>')"><i class="fa-solid fa-pen-to-square"></i></button></td>
													<td class="btns"> <button class="btn btn-danger shadow btn-xs sharp" onclick="eliminaDatosPersona('<?php echo $ver[0] ?>')"><i class="fa-solid fa-trash"></i></button></td>

												</tr>
											<?php endwhile; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="col-6" style="padding:0px !important;">
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="tipoPersonaTabla2" class="table table-hover table-condensed">
										<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" id="botonNuevo"><i class="fa-solid fa-square-plus"></i> Agregar nuevo</button>
										<thead>
											<tr>
												<th style="width:80%; text-align: center;">Tipo persona</th>
												<th></th>
												<th></th>
											</tr>
										</thead>
										<tbody>
											<?php while ($ver = mysqli_fetch_row($result2)) : ?>
												<tr>
													<td style="width: 90%;"> <?php echo $ver[1]; ?> </td>
													<td class="btns"> <button type="button" class="btn btn-primary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#modalEdicion" onclick="agregaDatosPersona('<?php echo $ver[0] ?>','<?php echo $ver[1] ?>')"><i class="fa-solid fa-pen-to-square"></i></button></td>
													<td class="btns"> <button class="btn btn-danger shadow btn-xs sharp" onclick="eliminaDatosPersona('<?php echo $ver[0] ?>')"><i class="fa-solid fa-trash"></i></button></td>

												</tr>
											<?php endwhile; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>
			<!--**********************************
            Content body end
        ***********************************-->
		</div>
		<!-- Datatable -->
		<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
		<script src="js/plugins-init/datatables.init.js"></script>

		<script src="vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
		<script>
			/* $(document).ready(function() {

				$('#tipoPersonaTabla1').DataTable({
					"fnInitComplete": function(oSettings, json) {
						console.log("ok");
					},
					columnDefs: [{
						orderable: false,
						targets: [1, 2]
					}],
					dom: 'frtBilp',
					buttons: [{
							extend: 'excelHtml5',
							text: '<i class="fa fa-file-excel"></i>',
							className: 'btn btn-success',
							titleAttr: 'Exportar a Excel'
						},

						{
							extend: 'pdfHtml5',
							text: '<i class="fa fa-file-pdf"></i>',
							className: 'btn btn-danger',
							titleAttr: 'Exportar a PDF'
						}

					],
					language: {
						"sProcessing": "Procesando...",
						"sLengthMenu": "Mostrar _MENU_ registros",
						"sZeroRecords": "No se encontraron resultados",
						"sEmptyTable": "Ningún dato disponible en esta tabla",
						"sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
						"sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
						"sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
						"sInfoPostFix": "",
						"sSearch": "Buscar:",
						"sUrl": "",
						"sInfoThousands": ",",
						"sLoadingRecords": "Cargando...",
						"oPaginate": {
							"sFirst": "Primero",
							"sLast": "Último",
							"sNext": "Siguiente",
							"sPrevious": "Anterior"
						},
						"oAria": {
							"sSortAscending": ": Activar para ordenar la columna de manera ascendente",
							"sSortDescending": ": Activar para ordenar la columna de manera descendente"
						},
						paginate: {
							sfirst: '<i class="fa fa-angle-double-right" aria-hidden="true">Primero</i>',
							next: '<i class="fa fa-angle-double-right" aria-hidden="true"></i>',
							previous: '<i class="fa fa-angle-double-left" aria-hidden="true"></i>',
						},
					}
				});

			}); */
		</script>

	</body>



	</html>


<?php
} else {
	header("location:../index.php");
}

?>