<?php
session_start();

require_once "../funciones/conexion.php";
$user = $_SESSION['idUser'];

//Cierra sesion despues de cierto tiempo
$obj = new cerrarSesion($user);
/* echo $obj->cerrarSesiones($user); */

if (isset($_SESSION['user'])) {
?>
	<!DOCTYPE html>
	<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Empresas</title>
		<link href="css/empresas.css" rel="stylesheet">

		<!-- Font awesome -->
		<script src="https://kit.fontawesome.com/56958c1105.js" crossorigin="anonymous"></script>

		<!-- Bootstrap -->

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
		<?php
		require_once "menu.php";
		?>
	</head>

	<body>

		<div id="tablaEmpresasLoad"></div>

		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Agregar nueva Empresa </h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<form class="row g-3 needs-validation" enctype="multipart/form-data" novalidate>
							<div class="container-fluid">
								<div class="row justify-content-around">
									<div class="col-md-12 position-relative">
										<label for="nombre" class="form-label">Nombre</label>
										<input type="text" class="form-control" id="nombre" required>
										<div class="invalid-tooltip">
											¡El nombre es necesario!
										</div>
									</div>

								</div>

								<div class="row justify-content-around">
									<div class="col-md-6 position-relative">
										<label for="razonSocial" class="form-label">Razón Social</label>
										<input type="text" class="form-control" id="razonSocial" required>
										<div class="invalid-tooltip">
											¡La Razón Social es necesaria!
										</div>
									</div>

									<div class="col-md-6 position-relative">
										<label for="RFC" class="form-label">RFC</label>
										<input type="text" class="form-control" id="RFC" required>
										<div class="invalid-tooltip">
											¡El RFC es necesario!
										</div>
									</div>
								</div>

								<div class="row justify-content-around">
									<div class="col-md-12 position-relative">
										<label for="calle" class="form-label">Calle</label>
										<input type="text" class="form-control" id="calle" required>
										<div class="invalid-tooltip">
											¡La Calle es necesaria!
										</div>
									</div>
								</div>

								<div class="row justify-content-around">
									<div class="col-md-6 position-relative">
										<label for="exterior" class="form-label">#Exterior</label>
										<input type="text" class="form-control" id="exterior" required>
										<div class="invalid-tooltip">
											¡El # Exterior es necesario!
										</div>
									</div>

									<div class="col-md-6 position-relative">
										<label for="interior" class="form-label">#Interior</label>
										<input type="text" class="form-control" id="interior" required>
										<div class="invalid-tooltip">
											¡El # Interior es necesaria!
										</div>
									</div>
								</div>

								<div class="row justify-content-around">
									<div class="col-md-6 position-relative">
										<label for="colonia" class="form-label">Colonia</label>
										<input type="text" class="form-control" id="colonia" required>
										<div class="invalid-tooltip">
											¡La Colonia es necesario!
										</div>
									</div>

									<div class="col-md-6 position-relative">
										<label for="CP" class="form-label">CP</label>
										<input type="text" class="form-control" id="CP" required>
										<div class="invalid-tooltip">
											¡El CP es necesario!
										</div>
									</div>

								</div>

								<div class="row justify-content-around">
									<div class="col-md-6 position-relative">
										<div class="row">
											<div class="col-xl-6">
												<div class="card">
													<div class="card-body">
														<div class="mb-4">
															<h4 class="card-title">Single select boxes</h4>
															<p>Select2 can take a regular select box like this...</p>
														</div>

														<select id="single-select">
															<option value="AL">Alabama</option>
															<option value="WY">Wyoming</option>
														</select>
													</div>
												</div>
											</div>
											<div class="invalid-tooltip">
												¡La Colonia es necesario!
											</div>
										</div>

										<div class="col-md-6 position-relative">
											<label for="CP" class="form-label">CP</label>
											<input type="text" class="form-control" id="CP" required>
											<div class="invalid-tooltip">
												¡El CP es necesario!
											</div>
										</div>

									</div>

									<div class="row justify-content-around">
										<div class="col-md-12 position-relative">
											<label for="logo" class="form-label">Logo</label>
											<input type="file" class="form-control" id="logo" required>
											<div class="invalid-tooltip">
												¡El logo es necesario!
											</div>
										</div>
									</div>

									<div class="row justify-content-between">
										<div class="col-md-auto">
											<button type="button" class="btn btn-third" data-bs-dismiss="modal">Cerrar</button>
										</div>
										<div class="col-md-auto">
											<button class="btn btn-primary" type="submit" id="guardar"><i class="fa-solid fa-floppy-disk"></i> Guardar</button>
										</div>
									</div>

								</div>
						</form>

					</div>

				</div>
			</div>
		</div>

	</body>

	</html>

	<script>
		//Script para valdiar formulario con Bootstrap 5
		(function() {
			'use strict'

			// Fetch all the forms we want to apply custom Bootstrap validation styles to
			var forms = document.querySelectorAll('.needs-validation')

			// Loop over them and prevent submission
			Array.prototype.slice.call(forms)
				.forEach(function(form) {
					form.addEventListener('submit', function(event) {
						if (!form.checkValidity()) {
							event.preventDefault()
							event.stopPropagation()
						}

						form.classList.add('was-validated')
					}, false)
				})
		})()
	</script>

	<script type="text/javascript">
		$(document).ready(function() {

			$('#tablaEmpresasLoad').load("vistas/empresas/tablaEmpresas.php");

			$('#guardar').click(function() {

				/* var formData = new FormData(document.getElementById("frmEmpresas"));
				$.ajax({
					url: "../procesos/pacientes/agregaHistoriaClinica.php",
					type: "post",
					dataType: "html",
					data: formData,
					cache: false,
					contentType: false,
					processData: false,

					success: function(r) {
						//alert(r);
						if (r == 1) {
							alertify.success('Exito');
							alertify.success('Historial agregado');
							setTimeout('window.location = "empresas.php";', 1000);
						} else {
							alertify.error('ERROR');
							alertify.alert('Error', 'El historial no se ha agregado. Refresque la pagina e intente de nuevo');
						}
					}
				});  */
			});

			/* $('#btnActualizaLaboratorio').click(function() {

				vacios = validarFormVacio('frmActualizaLaboratorio');

				if (vacios > 0) {
					alertify.alert('Datos incompletos', '¡Debes llenar todos los campos!');
					return false;
				}

				datos = $('#frmActualizaLaboratorio').serialize();
				$.ajax({
					type: "POST",
					data: datos,
					url: "../procesos/laboratorios/actualizaLaboratorio.php",
					success: function(r) {
						//alert(r);
						if (r == 1) {
							alertify.success('ÉXITO.');
							alertify.alert('Actualizado.', 'El laboratorio se actualizó de manera exitosa.',
								function() {
									setTimeout('window.location.reload();');
								});
						} else {
							alertify.error('ERROR.');
							if (r == 0) {
								alertify.alert('ERROR.', 'El laboratorio no se ha actualizado. Refresque la página e intente de nuevo.');
							}
							if (r == 2) {
								alertify.alert('ERROR.', 'Ya existe un laboratorio con el mismo nombre.');
							}
						}
					}
				});

			}); */
		});

		/* function agregaDato(idLaboratorio, laboratorio) {
			$('#idlaboratorio').val(idLaboratorio);
			$('#laboratorioU').val(laboratorio);
		} */

		/* function eliminaLaboratorio(idlaboratorio) {
			alertify.confirm('Eliminar laboratorio', '¿Esta seguro qué desea eliminar este laboratorio?',
				function() {
					$.ajax({
						type: "POST",
						data: "idlaboratorio=" + idlaboratorio,
						url: "../procesos/laboratorios/eliminarLaboratorio.php",
						success: function(r) {
							 alert(r);
							if (r == 1) {
								alertify.success('ÉXITO');
								alertify.success("Laboratorio eliminado");
								setTimeout('window.location.reload() ;', 1500);
							} else {
								alertify.error('ERROR');
								alertify.alert('Error', 'El laboratorio no se ha podido eliminar. Refresque la pagina e intente de nuevo');
							}
						}
					});
				},
				function() {
					alertify.error('Cancelado')
				});
		} */
	</script>

<?php
} else {
	header("location:../index.php");
}

?>