<?php
session_start();

require_once "../../../funciones/conexion.php";
$user = $_SESSION['idUser'];

//Cierra sesion despues de cierto tiempo
$obj = new cerrarSesion($user);
/* echo $obj->cerrarSesiones($user); */

if (isset($_SESSION['user'])) {
?>
	<!DOCTYPE html>
	<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Inicio</title>
		<link href="../../css/empresas.css" rel="stylesheet">

		<!-- Font awesome -->
		<script src="https://kit.fontawesome.com/56958c1105.js" crossorigin="anonymous"></script>

	</head>

	<body>
		<div class="container-body">
			<!--**********************************
            Content body start
        ***********************************-->
			<div class="content-body">
				<!-- row -->
				<div class="container-fluid">
					<div class="col-12">
						<div class="card">

							<div class="card-body">
								<div class="table-responsive">
									<table id="example3" class="display" style="min-width: 845px" id="tablaEmpresa">
										<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" id="botonNuevo"><i class="fa-solid fa-square-plus"></i> Agregar nuevo</button>
										<!-- <button class="btn btn-primary" data-toggle="modal" data-target="#modalNuevo" id="botonNuevo">Agregar Nuevo <i class="fa-solid fa-plus"></i></button> -->
										<thead>
											<tr>
												<th></th>
												<th>Empresa</th>
												<th>Razon social</th>
												<th>Contacto</th>
												<th>Telefono</th>
												<th>Email</th>
												<th>Alta</th>
												<th>Acción</th>
											</tr>
										</thead>
										<tbody>

										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--**********************************
            Content body end
        ***********************************-->
		</div>
	</body>

	</html>

<?php
} else {
	header("location:../index.php");
}

?>